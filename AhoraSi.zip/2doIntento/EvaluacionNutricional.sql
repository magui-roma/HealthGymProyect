USE HealthGym;
SELECT * FROM EvaluacionNutricional

GO

CREATE OR ALTER PROCEDURE [dbo].[spListarEvaNutricional]
AS
BEGIN
    SELECT Id, Saludable, Observacion, Evolucion, ReqEnergetico,
           ObjetivoNutri1, ObjetivoNutri2, ObjetivoNutri3
    FROM dbo.EvaluacionNutricional
    ORDER BY Id ASC;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[spInsertarEvaNutricional]
(
	@Saludable bit,
	@Observacion nvarchar(512),
	@Evolucion nvarchar(512),
	@ReqEnergetico int,
	@ObjetivoNutri1 nvarchar(50),
	@ObjetivoNutri2 nvarchar(50),
	@ObjetivoNutri3 nvarchar(50)
)
AS
BEGIN
	INSERT INTO EvaluacionNutricional(Saludable, Observacion, Evolucion, ReqEnergetico, ObjetivoNutri1, ObjetivoNutri2, ObjetivoNutri3)
	values (@Saludable, @Observacion, @Evolucion, @ReqEnergetico, @ObjetivoNutri1, @ObjetivoNutri2, @ObjetivoNutri3)
END
GO

CREATE OR ALTER PROCEDURE [dbo].[spEditarEvaNutricional]
(
	@Id bigint,
	@Saludable bit,
	@Observacion nvarchar(512),
	@Evolucion nvarchar(512),
	@ReqEnergetico int,
	@ObjetivoNutri1 nvarchar(50),
	@ObjetivoNutri2 nvarchar(50),
	@ObjetivoNutri3 nvarchar(50)
)
AS
BEGIN
		update EvaluacionNutricional set
		Saludable = @Saludable,
		Observacion = @Observacion,
		Evolucion = @Evolucion,
		ReqEnergetico = @ReqEnergetico,
		ObjetivoNutri1 = @ObjetivoNutri1,
		ObjetivoNutri2 = @ObjetivoNutri2,
		ObjetivoNutri3 = @ObjetivoNutri3
		where ID = @Id;
END
GO

SELECT * FROM PlanNutricional

GO

CREATE OR ALTER PROCEDURE [dbo].[spListarPlanNutricional]
AS
BEGIN
    SELECT Id, EvaluacionNutricional, Comida, Dia, Tipo, Alimento,
           ValorNutricional
    FROM dbo.PlanNutricional
    ORDER BY Id ASC;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[spInsertarPlanNutricional]
(
	@EvaluacionNutricional bigint,
	@Comida nvarchar(8),
	@Dia nvarchar(20),
	@Tipo nvarchar(10),
	@Alimento nvarchar(512),
	@ValorNutricional nvarchar(512)
)
AS
BEGIN
	INSERT INTO PlanNutricional(EvaluacionNutricional, Comida, Dia, Tipo, Alimento, ValorNutricional)
	values (@EvaluacionNutricional, @Comida, @Dia, @Tipo, @Alimento, @ValorNutricional)
END
GO

CREATE OR ALTER PROCEDURE [dbo].[spEditarPlanNutricional]
(
	@Id bigint,
	@EvaluacionNutricional bigint,
	@Comida nvarchar(8),
	@Dia nvarchar(20),
	@Tipo nvarchar(10),
	@Alimento nvarchar(512),
	@ValorNutricional nvarchar(512)
)
AS
BEGIN
		update PlanNutricional set
		EvaluacionNutricional = @EvaluacionNutricional,
		Comida = @Comida,
		Dia = @Dia,
		Tipo = @Tipo,
		Alimento = @Alimento,
		ValorNutricional = @ValorNutricional
		where Id = @Id;
END
GO