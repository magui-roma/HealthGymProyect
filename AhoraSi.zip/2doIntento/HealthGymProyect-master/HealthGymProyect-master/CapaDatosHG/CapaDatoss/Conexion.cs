﻿using System;
using System.Drawing.Text;
using Microsoft.Data.SqlClient;

public class Conexion
{
	private static readonly Conexion _instancia = new Conexion();
	public static Conexion Instancia
	{
		get { return Conexion._instancia; }
    }

    public SqlConnection Conectar()
    {
        SqlConnection cn = new SqlConnection(
            "Server=DESKTOP-6H3HFC5\\SQLEXPRESS;" +
            "Database=HealthGym;" +
            "Trusted_Connection=True;" +
            "TrustServerCertificate=True;");
        return cn;
    }
}