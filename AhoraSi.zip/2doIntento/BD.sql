
CREATE TABLE Persona(
	Id int primary key identity(1,1),
	Nombres nvarchar(256) not null,
	Apellidos nvarchar(256) not null,
	DNI char(8) not null,
	Telefono char(9) not null,
	Sexo bit not null default 0,
	Correo nvarchar(254) not null
)

CREATE TABLE Miembro(
	Id int primary key,
	MembresiaInicio date not null,
	MembresiaFin date not null,
	GrupoSanguineo varchar(3) not null,
	Seguro nvarchar(16) not null,
	FechaNacimiento date not null,

	foreign key (Id) references Persona(Id)
)

CREATE TABLE Cargos(
	Id int primary key identity(1,1),
	Nombre nvarchar(64) not null
)

CREATE TABLE Especialidad(
	Id int primary key identity(1,1),
	EspNombre nvarchar(32) not null
)

CREATE TABLE Trabajador(
	Id int primary key,
	Cargo int not null,
	Salario decimal(10,2) not null,
	Especialidad int null,

	check(Salario>0),

	foreign key (Id) references Persona(Id),
	foreign key (Cargo) references Cargos(Id),
	foreign key (Especialidad) references Especialidad(Id)
)

CREATE TABLE Logins(
	Id int primary key,
	Usuario varchar(12),
	Contrasena varchar(12),

	foreign key (Id) references Persona(Id)
)

CREATE TABLE Consulta(
	Id bigint primary key identity(1,1),
	Miembro int not null,
	Medico int not null,
	Coach int not null,
	Nutricionista int not null,
	Fecha datetime not null,

	foreign key (Miembro) references Miembro(Id),
	foreign key (Medico) references Trabajador(Id),
	foreign key (Coach) references Trabajador(Id),
	foreign key (Nutricionista) references Trabajador(Id)
)

CREATE TABLE Horario(
	Trabajador int not null,
	Dia varchar(20) not null,
	HoraInicio time not null,
	HoraFin time not null,

	foreign key (Trabajador) references Trabajador(Id)
)
--select CAST(GETDATE() as time)

CREATE TABLE EvaluacionFisica(
	Id bigint primary key identity(1,1),
	Peso decimal(3,2) not null,
	Estatura decimal(3,2) not null,
	IMC as ((Estatura*Estatura)/peso),
	PorcentajeGrasa decimal(3,2) not null default 0,
	Flexibilidad decimal(3,2) not null default 0,
	Fuerza decimal(3,2) not null default 0,
	Equilibrio decimal(3,2) not null default 0,
	Observacion nvarchar(512) not null,
	Objetivo nvarchar(128) not null,

	check(Flexibilidad>0),
	check(Flexibilidad<=100),
	check(Fuerza>0),
	check(Fuerza<=100),
	check(Equilibrio>0),
	check(Equilibrio<=100)
)

CREATE TABLE Ejercicios(
	Id int primary key identity(1,1),
	Nombre nvarchar(64) not null default '',
	Dificultad char(1) not null default '1',
	AtributoTecnico bit not null default 1,
	DescripcionTecnica nvarchar(512) not null default ''
)

CREATE TABLE PlanEntrenamiento(
	Id bigint primary key identity(1,1),
	Inicio date not null,
	Fin date not null,
	Asistencias int not null default 0,
	EjerciciosRealizados int not null default 0,
	ObservacionTecnica nvarchar(512) null default ''
)

CREATE TABLE RecursoDeportivo(
	Id int primary key identity(1,1),
	Nombre nvarchar(64) not null
)

CREATE TABLE RecursoDisponibilidad(
    Recurso INT NOT NULL,
    DiaSemana INT NOT NULL,
    Hora TIME NOT NULL,
    FOREIGN KEY (Recurso) REFERENCES RecursoDeportivo(Id)
)

CREATE TABLE HorarioEjercicios(
	PlanEntrenamiento bigint not null,
	Ejercicio int not null,
	Recurso int null,

	foreign key (PlanEntrenamiento) references PlanEntrenamiento(Id),
	foreign key (Ejercicio) references Ejercicios(Id),
	foreign key (Recurso) references RecursoDeportivo(Id)
)

CREATE TABLE HistoriaClinica(
	Id bigint primary key identity(1,1),
	Antecedentes nvarchar(1024) not null,
	Alergias nvarchar(512) not null,
	Deporte bit not null default 0,
	Fumador bit not null default 0,
)

CREATE TABLE EvaluacionNutricional(
	Id bigint primary key identity(1,1),
	Saludable bit not null default 0,
	Observacion nvarchar(512) null default '',
	Evolucion nvarchar(512) null default ''
)

ALTER TABLE EvaluacionNutricional
ADD 
    ReqEnergetico INT NOT NULL DEFAULT 0,
    ObjetivoNutri1 NVARCHAR(50) NULL DEFAULT '',
    ObjetivoNutri2 NVARCHAR(50) NULL DEFAULT '',
    ObjetivoNutri3 NVARCHAR(50) NULL DEFAULT '';

CREATE TABLE PlanNutricional(
	Id bigint primary key identity(1,1),
	EvaluacionNutricional bigint not null,
	Dia varchar(20) not null,
	Tipo varchar(10) not null,
	Alimento nvarchar(512) not null,
	ValorNutricional nvarchar(512) not null,

	foreign key (EvaluacionNutricional) references EvaluacionNutricional(Id)
)

ALTER TABLE PlanNutricional
ADD
	Comida NVARCHAR(8) NOT NULL;

ALTER TABLE PlanNutricional
DROP COLUMN Tipo, Alimento, ValorNutricional;

ALTER TABLE PlanNutricional
ADD
	Tipo varchar(10) not null,
	Alimento nvarchar(512) not null,
	ValorNutricional nvarchar(512) not null;

CREATE TABLE Expediente(
	Id bigint primary key identity(1,1),
	Miembro int not null,
	Consulta bigint not null,
	Fecha date not null,
	Observacion nvarchar(512) not null,
	HistoriaClinica bigint not null,
	EvaluacionFisica bigint not null,
	PlanEntrenamiento bigint not null,
	
	foreign key (Miembro) references Miembro(Id),
	foreign key (HistoriaClinica) references HistoriaClinica(Id),
	foreign key (PlanEntrenamiento) references PlanEntrenamiento(Id),
	foreign key (Consulta) references Consulta(Id)
)
